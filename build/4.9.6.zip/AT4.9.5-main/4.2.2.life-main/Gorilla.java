/*
 * Activity 4.9.2
 */
public class Gorilla extends Primate
{
  public Gorilla()
  {
    System.out.println("A gorilla arrives.");
  }

  public static void grunt()
  {
    System.out.println("The gorilla grunts.");
  }

  //added in 4.9.5 step 22
  public static void speak()
  {
    grunt();
  }
}