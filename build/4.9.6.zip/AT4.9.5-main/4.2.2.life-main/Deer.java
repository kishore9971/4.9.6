/*
 * Activity 4.9.2
 */
public class Deer extends Hooved
{
  public static void grunt()
  {
    System.out.println("The deer grunts.");
  }

  //added in 4.9.5 step 22
  public static void speak()
  {
    grunt();
  }
}