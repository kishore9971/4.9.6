/*
 * Activity 4.9.2
 */
public class Primate extends Animal
{
  public void forage()
  {
    System.out.println("The primate forages for food.");
  }
}